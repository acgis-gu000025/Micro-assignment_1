#Resets R environment if necessary
rm(list = ls())


library(rstudioapi)
#Sets working directory to the folder containing the current script
setwd(dirname(getActiveDocumentContext()$path))
#Checks to make sure path is correct
getwd()


#The function that returns the Otsu Threshold
otsu_threshold <- function(x, bins = 256) {
  
  #Builds histogram from image
  h <- hist(x, breaks = bins)
  counts <- h$counts
  mids <- h$mids
  total <- sum(counts)
  
  #Finds Probability
  prob <- counts / total
  
  #Find cumulative sums
  wgt_back <- cumsum(prob) #Background weight
  wgt_fore <- 1 - wgt_back  #Foreground weight
  
  #Find cumulative means
  mean_back <- cumsum(prob * mids) / wgt_back
  mean_fore <- (sum(prob * mids) - cumsum(prob * mids)) / wgt_fore
  
  #Between-class variance
  class_var <- wgt_back * wgt_fore * (mean_back - mean_fore)^2
  
  #Find max variance index
  tot_index <- which.max(class_var)
  
  #Corresponding threshold
  threshold <- mids[tot_index]
  
  #Returns the Otsu Threshold
  return(threshold)
}


#Reads the excel and and assigns it to a dataframe
install.packages("readxl") # Install if not already installed
library(readxl)
OntarioCDs <- read_excel("OntarioCDs.xlsx")

#Finds the otsu threshold of the the Pop2001 in the OntarioCDs
thresh_pop <- otsu_threshold(OntarioCDs$Pop2001)
print("The Otsu Threshold is")
thresh_pop


#Reads and assigns the included image to img, which is converted to grayscale as gray
library(png)
img <- readPNG("Grayscale-satellite-image-of-the-Fremont-River-basin.png")

#Checks the image dimension and finds it is not actually grayscale
dim(img)

#Converts to actual grayscale
grayimg <- 0.299*img[,,1] + 0.587*img[,,2] + 0.114*img[,,3]

#Plot the rasters to see the difference
plot(as.raster(img))
plot(as.raster(grayimg))

#Applies the otsu threshold on the grayscale image
thresh <- otsu_threshold(grayimg)
print("The Otsu Threshold is")
thresh

#Converts the grayscale image to monochrome based on the otsu_threshold
monoimg <- grayimg > thresh

plot(as.raster(monoimg))

#Plots a  nicer histogram of the grayscale image
hist(grayimg,
     breaks = 50,
     main = "Histogram of Grayscale Image with Otsu Threshold",
     xlab = "Pixel Intensity",
     ylab = "Frequency")

#Plot line demonstrating where the Otsu Threshold is
abline(v = thresh, col = "red", lwd = 3)
